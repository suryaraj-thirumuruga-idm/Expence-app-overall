import React from 'react'

export default function Footer() {
  return (
    <div>
        <hr />
        <center>
            <small>All rights Recerved || Shanjieev</small>
            <small> &#169;  2025</small>
        </center>
    </div>
  )
}
