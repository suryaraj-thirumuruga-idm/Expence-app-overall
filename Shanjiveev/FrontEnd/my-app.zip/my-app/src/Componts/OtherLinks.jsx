export const HomeGif = 'https://www.projectmanagementools.com/wp-content/uploads/2024/01/ezgif.com-animated-gif-maker.gif'

export const graph = 'https://clipart-library.com/images/8iG6ARRbT.gif'

export const API ="https://6427ac13161067a83bfeffb4.mockapi.io/api"

export const PieChartImg = 'https://i.pinimg.com/originals/c1/4d/42/c14d42b12f9f314b66c91076168a28ce.gif'

export const BarChart ='https://i.pinimg.com/originals/a4/2e/e3/a42ee3a08eb599c52f1893c30d02b157.gif'

export const PageNotImage = 'https://freefrontend.com/assets/img/html-funny-404-pages/CodePen-404-Page.gif'