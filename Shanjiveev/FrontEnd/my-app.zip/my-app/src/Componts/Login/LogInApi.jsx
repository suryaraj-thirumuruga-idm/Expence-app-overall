export const LogInAPI = "https://6427ac13161067a83bfeffb4.mockapi.io/cookies"

