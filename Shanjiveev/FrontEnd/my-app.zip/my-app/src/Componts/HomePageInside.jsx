import React from 'react'
import { BarChart } from './OtherLinks'

export default function HomePageinside() {
  return (
    <div >
       <center  >
       {/* <img src={PieChartImg} alt="" className='img-fluid w-25' />s */}
       <img src={BarChart} alt=""  className='img-fluid '/>
       </center>
    </div>
  )
}
